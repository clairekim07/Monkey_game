//create the gameState
var PLAY = 1;
var END = 0;
var gameState = PLAY;

//create the monkey variables
var monkey , monkey_running, monkey_stop;

//create the obstacles
var obstacle, obstacleImage;

//create the bananas
var banana ,bananaImage;

//create the groups
var bananaGroup, obstacleGroup;

//crate survivalTime
var survivalTime=0;

//create score
var score=0;

//create the ground
var ground;

function preload(){
   
  //preload the animation monkey_running
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  //preload the banana image
  bananaImage = loadImage("banana.png");
  
  //preload the obstacle image
  obstacleImage = loadImage("obstacle.png");
  
}



function setup() {
  //create the canvas
  createCanvas(500,300);
  
  //create the monkey
  monkey = createSprite(50,250,202,50);
  
  //add animation to monkey
  monkey.addAnimation("running", monkey_running);
  
  //scale monkey to make it smaller
  monkey.scale=.1;
  
  //make the ground
  Ground = createSprite(200,290,600,20);
  
  //define the new groups
  obstacleGroup = new Group();
  bananaGroup = new Group();

  //set the collider for the monkey as a rectangle
  monkey.setCollider("rectangle",0,0,monkey.width,monkey.height);
  monkey.debug = false;
  
}


function draw() {
  //set the background color to limeGreen
  background("limeGreen");
  
  //set the Ground color to green
  Ground.shapeColor=("green");
  
  //set the conditional programming whwn the gameState is in PLAY
  if(gameState === PLAY){
    
  //jump when the space key is pressed
  if(keyDown("space")&& monkey.y >= 100) {
    monkey.velocityY = -14;
    }
    
  //match the survivalTime to keep track of the frameCount/frameRate 
  survivalTime = Math.ceil(frameCount/frameRate());
    
  //when the banana is touching the monkey, destroy banana and add the score by 2
  if(bananaGroup.isTouching(monkey)){
    bananaGroup.destroyEach();
    score=score+2
       }
    
  //add gravity
  monkey.velocityY = monkey.velocityY + 0.8
  
  //spawn the bananas and the obstacles
  spawnbanana();
  spawnobstacle();
    
    //when the obstacle is touching the monkey, destroy both groups and the monkey and put gameState as END
  if(obstacleGroup.isTouching(monkey)){
        //trex.velocityY = -12;
    obstacleGroup.destroyEach();
    bananaGroup.destroyEach();
    monkey.destroy();
    gameState = END;
    }
  }
   //set the conditional programming for END
   else if (gameState === END) {
    //make the text Game Over ,50, and red
    textSize(50);
    fill("red");
    text("Game Over",100,150);
     
    //change the monkey animation
    monkey.changeAnimation("collided", monkey_stop);
     
    //set the survivalTime back to 0
    survivalTime=0;
     
    //set the score back to 0
    score=0;
     
    //set the monkey velocity back to 0
    monkey.velocityY = 0
      
    //set lifetime of the game objects so that they are never destroyed
    obstacleGroup.setLifetimeEach(-1);
    bananaGroup.setLifetimeEach(-1);
     
    //set the velocity of the groups to 0
    obstacleGroup.setVelocityXEach(0);
    bananaGroup.setVelocityXEach(0);    
   }
  
 
  //stop monkey from falling down
  monkey.collide(Ground);
  
  //draw the sprites
  drawSprites();
  
  //make the survivalTime text navy and size 20
  textSize(20);
  fill("navy");
  text("Survival Time : "+survivalTime,50,20);
  
  //make the survivalTime text navy and size 20
  textSize(20);
  fill("navy");
  text("Score: "+score,280,20);
}
//create the function spawnbanana
function spawnbanana(){
//make the sprite appear every framCount that is divisible by 80
 if (frameCount % 80 === 0){
   //create the banana sprite
   var banana = createSprite(600,Math.round(random(50,150)),10,40);
   //add banana its image
   banana.addImage(bananaImage);
   //give the banana velocity
   banana.velocityX = -6;
   //scale the banana by .15 to make it smaller
   banana.scale=.15;
    //set the liftime as 300
   banana.lifetime = 300;
   //add banana to the bananagroup
   bananaGroup.add(banana);
 }
}
//create the function spawnobstacle
function spawnobstacle(){
  //make the sprite appear every framCount that is divisible by 80
 if (frameCount % 80 === 0){
  //create the obstacle sprite
   var obstacle = createSprite(600,270,10,40);
  //add image to obstacle
   obstacle.addImage(obstacleImage);
  //give obstacle velocity
   obstacle.velocityX = -6;
  //scale the obstacle to .12 to make it smaller
   obstacle.scale=.12;
  //set the lifetime to 300
   obstacle.lifetime = 300;
  //add obstacle to the group
   obstacleGroup.add(obstacle);
 }
}




